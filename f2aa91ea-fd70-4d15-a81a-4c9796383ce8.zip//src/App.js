import React, { useState, useEffect } from "react";
import quizData from "./quizData";

function App() {
  const [quizStarted, setQuizStarted] = useState(false);
  const [currentQ, setCurrentQ] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState(null);
  const [showResult, setShowResult] = useState(false);
  const [timer, setTimer] = useState(60);

  useEffect(() => {
    let interval;
    if (quizStarted && !showResult) {
      interval = setInterval(() => {
        setTimer((prev) => {
          if (prev === 1) {
            handleTimeout();
            return 60;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [quizStarted, showResult]);

  const handleAnswer = (option) => {
    setSelected(option);
    if (option === quizData[currentQ].answer) {
      setScore((prev) => prev + 1);
    }
  };

  const handleTimeout = () => {
    if (!selected) {
      setScore((prev) => prev - 1);
    }
    nextQuestion();
  };

  const nextQuestion = () => {
    setSelected(null);
    setTimer(60);
    if (currentQ + 1 < quizData.length) {
      setCurrentQ(currentQ + 1);
    } else {
      setShowResult(true);
    }
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      {!quizStarted ? (
        <div>
          <h1>Welcome to the Quiz!</h1>
          <button onClick={() => setQuizStarted(true)}>Start</button>
        </div>
      ) : showResult ? (
        <div>
          <h2>Final Score: {score}</h2>
          <p>
            You answered {score} out of {quizData.length} correctly.
          </p>
        </div>
      ) : (
        <div>
          <h2>{quizData[currentQ].question}</h2>
          <div style={{ margin: "20px 0" }}>
            {quizData[currentQ].options.map((option, i) => (
              <button
                key={i}
                style={{
                  background:
                    selected === option
                      ? option === quizData[currentQ].answer
                        ? "green"
                        : "red"
                      : "",
                  color: selected === option ? "white" : "",
                  margin: "5px",
                  padding: "10px 20px",
                  cursor: selected ? "not-allowed" : "pointer",
                }}
                onClick={() => handleAnswer(option)}
                disabled={!!selected}
              >
                {option}
              </button>
            ))}
          </div>
          {selected && <button onClick={nextQuestion}>Next</button>}
          <p>⏳ Time left: {timer}s</p>
        </div>
      )}
    </div>
  );
}

export default App;
