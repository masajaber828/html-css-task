const quizData = [
  {
    question: "ما هي عاصمة فلسطين؟",
    options: ["القدس", "غزة", "نابلس", "الخليل"],
    answer: "القدس",
  },
  {
    question: "ما هو أكبر كوكب في المجموعة الشمسية؟",
    options: ["الأرض", "المريخ", "المشتري", "الزهرة"],
    answer: "المشتري",
  },
  {
    question: "ما هو لغة البرمجة التي نستخدمها في React؟",
    options: ["Python", "JavaScript", "C#", "Java"],
    answer: "JavaScript",
  },
];

export default quizData;
